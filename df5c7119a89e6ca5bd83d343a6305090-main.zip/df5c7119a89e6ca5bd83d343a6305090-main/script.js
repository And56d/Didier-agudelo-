function buscarSolicitud() {
  var numeroSolicitud = document.getElementById('numeroSolicitud').value;
  var tabla = document.getElementById('tablaSolicitudes').getElementsByTagName('tbody')[0];
  var filas = tabla.getElementsByTagName('tr');

  for (var i = 0; i < filas.length; i++) {
    var celdas = filas[i].getElementsByTagName('td');
    var numSolicitudTabla = celdas[0].textContent;

    if (numSolicitudTabla === numeroSolicitud) {
      var sku = celdas[1].textContent;
      var cantidad = celdas[2].textContent;
      var fechaSalida = celdas[3].textContent;
      var fechaEntrada = celdas[4].textContent;

      // Mostrar los datos encontrados en los campos de entrada
      document.getElementById('sku').value = sku;
      document.getElementById('cantidad').value = cantidad;
      document.getElementById('fechaSalida').value = fechaSalida;
      document.getElementById('fechaEntrada').value = fechaEntrada;

      return; // Salir del bucle si se encuentra el número de solicitud
    }
  }

  // Mostrar un mensaje si no se encuentra el número de solicitud
  alert('Número de solicitud no encontrado');
}

function modificarFechaEntrada() {
  var numeroSolicitud = document.getElementById('numeroSolicitud').value;
  var nuevaFechaEntrada = document.getElementById('fechaEntrada').value;
  var tabla = document.getElementById('tablaSolicitudes').getElementsByTagName('tbody')[0];
  var filas = tabla.getElementsByTagName('tr');

  for (var i = 0; i < filas.length; i++) {
    var celdas = filas[i].getElementsByTagName('td');
    var numSolicitudTabla = celdas[0].textContent;

    if (numSolicitudTabla === numeroSolicitud) {
      celdas[4].textContent = nuevaFechaEntrada;

      // Limpiar los campos de entrada después de modificar la fecha
      document.getElementById('fechaEntrada').value = '';

      return; // Salir del bucle si se encuentra el número de solicitud
    }
  }

  // Mostrar un mensaje si no se encuentra el número de solicitud
  alert('Número de solicitud no encontrado');
}

function guardarDatos() {
  var numeroSolicitud = document.getElementById('numeroSolicitud').value;
  var sku = document.getElementById('sku').value;
  var cantidad = document.getElementById('cantidad').value;
  var fechaSalida = document.getElementById('fechaSalida').value;
  var fechaEntrada = document.getElementById('fechaEntrada').value;

  var tabla = document.getElementById('tablaSolicitudes').getElementsByTagName('tbody')[0];
  var filas = tabla.getElementsByTagName('tr');

  // Buscar si ya existe la solicitud en la tabla
  for (var i = 0; i < filas.length; i++) {
    var celdas = filas[i].getElementsByTagName('td');
    var numSolicitudTabla = celdas[0].textContent;

    if (numSolicitudTabla === numeroSolicitud) {
      celdas[1].textContent = sku;
      celdas[2].textContent = cantidad;
      celdas[3].textContent = fechaSalida;
      celdas[4].textContent = fechaEntrada;

      // Limpiar los campos de entrada después de guardar los datos
      document.getElementById('numeroSolicitud').value = '';
      document.getElementById('sku').value = '';
      document.getElementById('cantidad').value = '';
      document.getElementById('fechaSalida').value = '';
      document.getElementById('fechaEntrada').value = '';

      return; // Salir del bucle si se encuentra el número de solicitud
    }
  }

  // Si no se encuentra la solicitud, crear una nueva fila en la tabla
  var fila = tabla.insertRow();
  fila.insertCell().textContent = numeroSolicitud;
  fila.insertCell().textContent = sku;
  fila.insertCell().textContent = cantidad;
  fila.insertCell().textContent = fechaSalida;
  fila.insertCell().textContent = fechaEntrada;

  // Limpiar los campos de entrada después de guardar los datos
  document.getElementById('numeroSolicitud').value = '';
  document.getElementById('sku').value = '';
  document.getElementById('cantidad').value = '';
  document.getElementById('fechaSalida').value = '';
  document.getElementById('fechaEntrada').value = '';
}

// Importar la biblioteca `google-spreadsheet`
const SpreadsheetApp = require('google-spreadsheet');

// Crear una instancia de la clase `SpreadsheetApp` para acceder a la hoja de cálculo
const spreadsheet = SpreadsheetApp.openById('14pr2enKkKquv4o99izQbv2sO3ONVBp4rwEo58eVCBfo');

// Obtener la hoja de cálculo activa
const sheet = spreadsheet.getActiveSheet();

// Cargar los datos de la hoja de cálculo
const datos = sheet.getDataRange().getValues();

// Usar los datos de la hoja de cálculo para realizar las tareas que necesitas
// Obtener los datos de la solicitud
var numeroSolicitud = document.getElementById('numeroSolicitud').value;
var sku = document.getElementById('sku').value;
var cantidad = document.getElementById('cantidad').value;
var fechaSalida = document.getElementById('fechaSalida').value;
var fechaEntrada = document.getElementById('fechaEntrada').value;

// Validar los datos de la solicitud
// Obtener el número de solicitud
var numeroSolicitud = document.getElementById('numeroSolicitud').value;

// Buscar la solicitud en la hoja de cálculo
const datosSolicitud = sheet.getDataRange().getValues().find(row => row[0] === numeroSolicitud);

// Si la solicitud se encuentra, devolverla
if (datosSolicitud !== null) {
  // Devolver la solicitud
  return datosSolicitud;
} else {
  // Si la solicitud no se encuentra, devolver `null`
  return null;
}
